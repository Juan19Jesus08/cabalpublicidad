<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Adquirir extends Model
{
    protected $table='adquirir';
    public $timestamps = false;
    
   /* protected $fillable = [
        'fecha_de_adquisicion','avance','certificado','comentario','calificacion'
        ];*/

    

}
