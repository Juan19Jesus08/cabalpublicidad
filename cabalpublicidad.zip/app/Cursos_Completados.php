<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cursos_Completados extends Model
{
    protected $table='cursos_completados';
    public $timestamps = false;
   
}
