
<img src="/images/cabal.jpg" alt="Flowers in Chania"> 
{{ $message }}
<br/>
<br/>
{{$message2}}
<br/>
<br/>
{{$message3}}
<br/>
<br/>
{{$message4}}
<br/>
<br/>
{{$message5}}



