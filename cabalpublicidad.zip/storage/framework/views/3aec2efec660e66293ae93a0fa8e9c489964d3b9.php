
<img src="/images/cabal.jpg" alt="Cabal"> 
<?php echo e($message); ?>

<br/>
<br/>
<?php echo e($message2); ?>

<br/>
<br/>
<?php echo e($message3); ?>

<br/>
<br/>
<?php echo e($message4); ?>

<br/>
<br/>
<?php echo e($message5); ?>




<?php /**PATH C:\Users\juani\Pictures\cabalpublicidad\resources\views/email_template.blade.php ENDPATH**/ ?>