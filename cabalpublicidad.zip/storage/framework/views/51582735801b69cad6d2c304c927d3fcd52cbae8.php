<?php $__env->startSection('contenido'); ?>
<?php
$valor= $_GET['id_categoria'];


$query = "select * from categoria where id_categoria='$valor'";

    $data=DB::select($query);
    
    foreach($data as $item)
    {
        $cate=$item->descripcion;
        $id=$item->id_categoria;
    }
    
    
    
?>
<?php echo e(Form::open(array('action' => 'CategoriaController@eliminar', 'method' => 'post','id'=>'student-settings','name'=>'loginform'))); ?>

										<!--<form name="loginform" id="student-settings" class="student-settings" method="post">-->
						
                        <label>
							
                            <?php echo e(Form::hidden('id_show', $id)); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>


						<label>
							Se eliminara la categoria : <?php echo $cate?>
                            <?php echo e(Form::hidden('categoria_show', $cate)); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>


						<?php echo Form::submit( 'Aceptar', ['class' => 'btn btn-info btn-block', 'name' => 'submitbutton', 'value' => 'login']); ?>

						 <?php echo e(Form::close()); ?>

                         <a class="btn btn-info btn-block" href="/Admin_categoria " >Cancelar</a>
                        
                    
                         


<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\juani\Pictures\cabalpublicidad\resources\views//Admin/Categoria/delete.blade.php ENDPATH**/ ?>