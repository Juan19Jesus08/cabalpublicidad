

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Document</title>
        <style>
        h1{
        text-align: center;
        text-transform: uppercase;
        }
        .contenido{
        font-size: 20px;
        }
        #primero{
        background-color: #ccc;
        }
        #segundo{
        color:#44a359;
        }
        #tercero{
        text-decoration:line-through;
        }
    </style>
    </head>
    <body>
    
    <img class="size-full wp-image-5499 aligncenter" src="http://cabalpublicidad.com/wp-content/uploads/2018/12/cabal-2.jpg" alt="cabal" width="250" height="233" />
<p style="text-align: center;"><span style="font-size: 24pt; font-family: 'times new roman', times, serif; color: #0000ff;">EL CENTRO DE CAPACITACIÓN CABAL</span></p>
<p style="text-align: center;"><span style="font-size: 24pt; font-family: 'times new roman', times, serif;">                       </span></p>


&nbsp;
<p style="text-align: center;"><span style="font-size: 24pt; font-family: 'times new roman', times, serif;">  <span style="font-size: 18pt;">OTORGA EL PRESENTE DIPLOMA A:</span></span></p>
&nbsp;
<p style="text-align: center;"><span style="font-size: 24pt;">   <span style="font-size: 18pt;"> <strong> <?php echo e($nombre); ?></strong></span></span></p>
&nbsp;
<p style="text-align: center;"><span style="font-size: 24pt;"> <span style="font-size: 18pt;"><span style="font-family: 'times new roman', times, serif;">POR HABER CONCLUIDO EL CURSO DE:</span></span></span></p>
<span style="font-size: 18pt;">                                                   <?php echo e($curso); ?></span>
<p style="text-align: left;"><span style="font-family: 'times new roman', times, serif;">                                                                   <span style="font-size: 14pt;"> <strong>Finalizado el</strong></span></span><span style="font-size: 14pt;"><strong> <?php echo e($fecha); ?> </strong></span></p>
&nbsp;
<p style="text-align: center;"><span style="font-family: 'times new roman', times, serif;"><strong>             C.P. Y M.F. DANIEL CABAL</strong></span></p>
<p style="text-align: center;">              <strong>Director</strong></p>
&nbsp;

        
    </body>
</html>

<?php /**PATH C:\Users\juani\Pictures\cabalpublicidad\resources\views//cliente_principal/pdf.blade.php ENDPATH**/ ?>