<?php $__env->startSection('contenido'); ?>
<?php
$query = "select * from rol ";

$data=DB::select($query);



?>
<?php echo e(Form::open(array('action' => 'UsuarioController@insertar', 'method' => 'post','id'=>'student-settings','name'=>'loginform'))); ?>

										<!--<form name="loginform" id="student-settings" class="student-settings" method="post">-->
					
                        <label>
							Email 
                            <?php echo e(Form::email('email_show', '', array('id' => 'email_show',  'placeholder' => 'Email'))); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Nombre
                            <?php echo e(Form::text('nombre_show', '', array('id' => 'nombre_show',  'placeholder' => 'Nombre'))); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Contraseña
                            <?php echo e(Form::password('contrasenia_show', array('id' => 'contrasenia_show', 'placeholder' => 'Contraseña'))); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Rol
                            <select class="form-control" name="rol_show">

  <option>Elige un rol</option>

  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($item->id_rol); ?>" > <?php echo e($item->descripcion); ?> </option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    </select>
							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                       

						<?php echo Form::submit( 'insertar', ['class' => 'btn btn-info btn-block', 'name' => 'submitbutton', 'value' => 'login']); ?>

						 <?php echo e(Form::close()); ?>

                         <a class="btn btn-info btn-block" href="/Admin_Usuario " >Cancelar</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\juani\Pictures\cabalpublicidad\resources\views//Admin/Usuario/insert.blade.php ENDPATH**/ ?>