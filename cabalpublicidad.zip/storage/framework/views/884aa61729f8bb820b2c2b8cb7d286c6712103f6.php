<?php $__env->startSection('contenido'); ?>
<?php
$valor= $_GET['id_curso'];


$query = "select cursos.nombre,cursos.descripcion,cursos.precio,cursos.fecha_creacion,cursos.id_curso,categoria.descripcion as cate,categoria.id_categoria from cursos inner join categoria on cursos.id_categoria=categoria.id_categoria where id_curso='$valor'";

    $data=DB::select($query);
    
    foreach($data as $item)
    {
        $nombre=$item->nombre;
        $descripcion=$item->descripcion;
        $precio=$item->precio;
        $fecha=$item->fecha_creacion;
        $id=$item->id_curso;
        $categoria=$item->cate;
        $id_cate=$item->id_categoria;

    }

    $query2="select * from categoria";
    $data2=DB::select($query2);
    
?>
<?php echo e(Form::open(array('action' => 'CursosController@actualizar', 'method' => 'post','id'=>'student-settings','name'=>'loginform'))); ?>

										<!--<form name="loginform" id="student-settings" class="student-settings" method="post">-->
						
                        <label>
							
                            <?php echo e(Form::hidden('id_show', $id)); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>


						<label>
							Nombre
                            <?php echo e(Form::text('nombre_show', $nombre)); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Descripcion
                            <?php echo e(Form::text('descripcion_show', $descripcion)); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Precio
                            <?php echo e(Form::text('precio_show', $precio)); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Categoria
                            <select class="form-control" name="categoria_show">

  <option value="<?php echo e($id_cate); ?>" > <?php echo e($categoria); ?> </option>

  <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($item->id_categoria); ?>" > <?php echo e($item->descripcion); ?> </option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    </select>
						</label>
                        <br/>
                        <label>
							Nombre
                            <?php echo e(Form::date('fecha_show', $fecha)); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>


						<?php echo Form::submit( 'actualizar', ['class' => 'btn btn-info btn-block', 'name' => 'submitbutton', 'value' => 'login']); ?>

						 <?php echo e(Form::close()); ?>

                         <a class="btn btn-info btn-block" href="/Admin_cursos " >Cancelar</a>
                         


<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\juani\Pictures\cabalpublicidad\resources\views//Admin/Cursos/edit.blade.php ENDPATH**/ ?>