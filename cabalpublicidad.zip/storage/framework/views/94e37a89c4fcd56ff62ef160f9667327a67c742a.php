<?php $__env->startSection('contenido'); ?>
<?php
$query = "select * from categoria ";

$data=DB::select($query);



?>
<?php echo e(Form::open(array('action' => 'CursosController@insertar', 'method' => 'post','id'=>'student-settings','name'=>'loginform'))); ?>

										<!--<form name="loginform" id="student-settings" class="student-settings" method="post">-->
						
						<label>
							Nombre
                            <?php echo e(Form::text('nombre_show', '', array('id' => 'nombre_show',  'placeholder' => 'Nombre'))); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Descripcion 
                            <?php echo e(Form::text('descripcion_show', '', array('id' => 'descripcion_show',  'placeholder' => 'Descripcion'))); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Precio
                            <?php echo e(Form::text('precio_show', '', array('id' => 'precio_show',  'placeholder' => 'Precio'))); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Categoria
                            <select class="form-control" name="categoria_show">

  <option>Elige una categoria</option>

  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($item->id_categoria); ?>" > <?php echo e($item->descripcion); ?> </option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    </select>
							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Fecha de Creacion
                            <?php echo e(Form::date('fecha_show', '', array('id' => 'fecha_show',  'placeholder' => 'Fecha de creacion'))); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>

						<?php echo Form::submit( 'insertar', ['class' => 'btn btn-info btn-block', 'name' => 'submitbutton', 'value' => 'login']); ?>

						 <?php echo e(Form::close()); ?>

                         <a class="btn btn-info btn-block" href="/Admin_cursos " >Cancelar</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\juani\Pictures\cabalpublicidad\resources\views//Admin/Cursos/insert.blade.php ENDPATH**/ ?>