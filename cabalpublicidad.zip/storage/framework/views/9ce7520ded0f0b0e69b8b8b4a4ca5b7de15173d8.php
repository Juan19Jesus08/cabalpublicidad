<?php $__env->startSection('contenido'); ?>
<?php
$query = "select * from cursos ";

$data=DB::select($query);
print_r($data);


?>
<?php echo e(Form::open(array('action' => 'ClasesController@insertar', 'method' => 'post','id'=>'student-settings','name'=>'loginform'))); ?>

										<!--<form name="loginform" id="student-settings" class="student-settings" method="post">-->
						
						<label>
							Nombre
                            <?php echo e(Form::text('nombre_show', '', array('id' => 'nombre_show',  'placeholder' => 'Nombre'))); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Url 
                            <?php echo e(Form::text('url_show', '', array('id' => 'url_show',  'placeholder' => 'URL'))); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Descripcion
                            <?php echo e(Form::text('descripcion_show', '', array('id' => 'descripcion_show',  'placeholder' => 'Descripcion'))); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Cursos
                            <select class="form-control" name="curso_show">

  <option>Elige un curso</option>

  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($item->id_curso); ?>" > <?php echo e($item->nombre); ?> </option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    </select>
							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                       

						<?php echo Form::submit( 'insertar', ['class' => 'btn btn-info btn-block', 'name' => 'submitbutton', 'value' => 'login']); ?>

						 <?php echo e(Form::close()); ?>

                         <a class="btn btn-info btn-block" href="/Admin_clases " >Cancelar</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\juani\Pictures\cabalpublicidad\resources\views//Admin/Clases/insert.blade.php ENDPATH**/ ?>