<?php $__env->startSection('contenido'); ?>
<?php
$valor= $_GET['id_clase'];


$query = "SELECT cursos.id_curso,clases.id_clase,clases.nombre,clases.url,clases.descripcion,clases.duracion,cursos.nombre as curso FROM clases inner join cursos on cursos.id_curso=clases.id_curso where clases.id_clase='$valor'";

    $data=DB::select($query);
   
    foreach($data as $item)
    {
        $id=$item->id_clase;
        $nombre=$item->nombre;
        $url=$item->url;
        $descripcion=$item->descripcion;
        $duracion=$item->duracion;
        $curso=$item->curso;
        $id_curso=$item->id_curso;
        
        //$categoria=$item->cate;
        //$id_cate=$item->id_categoria;
    }

    $query2="select * from cursos";
    $data2=DB::select($query2);
    
?>
<?php echo e(Form::open(array('action' => 'ClasesController@actualizar', 'method' => 'post','id'=>'student-settings','name'=>'loginform'))); ?>

										<!--<form name="loginform" id="student-settings" class="student-settings" method="post">-->
						
                        <label>
							
                            <?php echo e(Form::hidden('id_show', $id)); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>


						<label>
							Nombre
                            <?php echo e(Form::text('nombre_show', $nombre)); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							URL
                            <?php echo e(Form::text('url_show', $url)); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Descripcion
                            <?php echo e(Form::text('descripcion_show', $descripcion)); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							
                            <?php echo e(Form::hidden('duracion_show', $duracion)); ?>

							<!--<input type="text" name="log" value=""/>-->
						</label>
                        <br/>
                        <label>
							Curso
                            <select class="form-control" name="curso_show">

  <option value="<?php echo e($id_curso); ?>" > <?php echo e($curso); ?> </option>

  <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($item->id_curso); ?>" > <?php echo e($item->nombre); ?> </option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    </select>
						</label>
                        <br/>
                        

						<?php echo Form::submit( 'actualizar', ['class' => 'btn btn-info btn-block', 'name' => 'submitbutton', 'value' => 'login']); ?>

						 <?php echo e(Form::close()); ?>

                         <a class="btn btn-info btn-block" href="/Admin_cursos " >Cancelar</a>
                         


<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\juani\Pictures\cabalpublicidad\resources\views//Admin/Clases/edit.blade.php ENDPATH**/ ?>